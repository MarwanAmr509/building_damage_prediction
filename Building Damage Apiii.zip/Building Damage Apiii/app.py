import pandas as pd
import numpy as np
from flask import Flask, request, jsonify, render_template, send_file, redirect, url_for
from joblib import load
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)

# Load the models
damage_model_pipeline = load('./damage_model_pipeline.joblib')
floor_count_model_pipeline = load('./count_floors_logistic_regression_84_model.joblib')
height_model_pipeline = load('./height_prediction_xgboost_regressor_55_model.joblib')

@app.route('/', methods=['GET'])
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']
    if file and file.filename.endswith('.csv'):
        filename = secure_filename(file.filename)
        filepath = os.path.join('uploads', filename)
        file.save(filepath)
        
        data = pd.read_csv(filepath)
        
        # Manually include all categorical columns, including those that start with 'has'
        categorical_columns = [
            'land_surface_condition', 'foundation_type', 'roof_type', 'ground_floor_type',
            'other_floor_type', 'position', 'plan_configuration', 'legal_ownership_status',
            'has_superstructure_adobe_mud', 'has_superstructure_mud_mortar_stone', 
            'has_superstructure_stone_flag', 'has_superstructure_cement_mortar_stone', 
            'has_superstructure_mud_mortar_brick', 'has_superstructure_cement_mortar_brick', 
            'has_superstructure_timber', 'has_superstructure_bamboo', 
            'has_superstructure_rc_non_engineered', 'has_superstructure_rc_engineered', 
            'has_superstructure_other', 'has_secondary_use', 'has_secondary_use_agriculture', 
            'has_secondary_use_hotel', 'has_secondary_use_rental', 
            'has_secondary_use_institution', 'has_secondary_use_school', 
            'has_secondary_use_industry', 'has_secondary_use_health_post', 
            'has_secondary_use_gov_office', 'has_secondary_use_use_police', 
            'has_secondary_use_other'
        ]
        
        # Ensure all categorical data are strings and handle missing values
        for column in categorical_columns:
            if column in data.columns:
                data[column] = data[column].astype(str).fillna('missing')
        
        numerical_columns = data.select_dtypes(include=['int64', 'float64']).columns
        for column in numerical_columns:
            if column in data.columns:
                data[column] = data[column].fillna(-999)
        
        # Handling other specific columns with missing values
        data.fillna('missing', inplace=True)
        
        try:
            # Predict damage grade
            damage_predictions = damage_model_pipeline.predict(data)
            data['damage_grade'] = damage_predictions
            
            # Prepare input for the second model
            data['damage_grade'] += 1
            
            # Predict count of floors after earthquake
            # floor_count_predictions = floor_count_model_pipeline.predict(data)
            # data['count_floors_post_eq'] = floor_count_predictions
            
            # Ensure count_floors_post_eq does not exceed count_floors_pre_eq
            # data['count_floors_post_eq'] = data[['count_floors_post_eq', 'count_floors_pre_eq']].min(axis=1)
            
            # Predict height of the building
            height_predictions = height_model_pipeline.predict(data)
            
            # Adjust height predictions: zero for negative, round for positive
            data['height_ft_post_eq'] = np.where(height_predictions < 0, 0, np.round(height_predictions))

    #############################
            floor_count_predictions = floor_count_model_pipeline.predict(data)
            data['count_floors_post_eq'] = floor_count_predictions
            
            # Save the full data with all inputs and outputs
            result_path = os.path.join('results', 'predictions_' + filename)
            data.to_csv(result_path, index=False)
            
            # Select specified columns for display
            display_columns = [
                'count_floors_pre_eq', 'age_building', 'plinth_area_sq_ft', 'height_ft_pre_eq', 
                'damage_grade', 'count_floors_post_eq', 'height_ft_post_eq'
            ]
            display_data = data[display_columns]
            
            # Display only the first 10 rows
            display_data = display_data.head(10)
            html_table = display_data.to_html(classes='data')
            
            return render_template('result.html', table=html_table, filename=result_path)
        
        except Exception as e:
            return jsonify({'error': str(e)})

    return "Invalid file format, please upload a CSV."

@app.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    return send_file(filename, as_attachment=True)

if __name__ == '__main__':
    app.run(port=3001, debug=True)
